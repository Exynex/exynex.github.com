import processing.core.*; 
import processing.xml.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class nyancat extends PApplet {

int num_enemys = 10;
Enemy[] enemies = new Enemy[num_enemys];
Player player;

boolean _DEBUG_ = false;
boolean howtoplay = false;
boolean _CIRCLE_HITTEST_ = false;

Button replay = new Button(252, 10, 180, 50, "Replay", 292, 48);
Button main   = new Button(332-80, 85, 180, 50, "Main Menu", 260, 122);
Button start  = new Button(10, 410, 960, 60, "Start Game", 430, 450);

int count = 0;
int countControl = 0;
int time = 0;
int minutes = 0;
String score = "";

int clr;
int startingSpeed = 2;
int speed = startingSpeed;

float angle = random(-5, 5);

boolean gameGo = false;
boolean gameOver = false;
boolean mainMenu = true;

PFont font;
PImage b;
PImage space;
PImage meteor;

public void setup() {
  size(980, 480);
  smooth();
  noCursor();


  clr = color(255, 0, 0, 0);
  frameRate(60);

  font = loadFont("ArialMT-48.vlw");
  b = loadImage("nyancat.gif");
  space = loadImage("space.jpg");
  meteor = loadImage("meteor.png");

  // create enemys
  for (int i = 0; i < num_enemys; i++) {
    enemies[i] = new Enemy();
  }

  // create player
  player = new Player();
}


public void updateSpeed() {
  speed += 1;
  angle = random(-10, 10);
  clr = color(random(0, 255), random(0, 255), 0);
}



public void collisionDetect() {
  for (int i = 0; i < num_enemys; i++) {
    if (    player.hitTest( (Sprite) enemies[i]) ) {
      gameOver = true;
    }
  }
}

public void draw() {



  fill(255);
  textFont(font, 30);
  stroke(100);
  strokeWeight(4);

  if ( mainMenu ) {
    background(255);
    fill(0xff02A8BC);
    noStroke();
    rect(340, 8, 340, 60);
    stroke(0, 0, 0);

    fill(0xff000000);
    textSize(60);
    text("NYAN CAT!", 350, 60);
    textSize(30);
    text("Do not to let your Nyan Cat touch the dots!", 230, 115);
    image(b, 300, 140);
    start.draw();
    if ( start.clicked ) {
      gameGo = true;
      mainMenu = false;
      start = new Button(10, 410, 960, 60, "Start Game", 430, 450);
    }
  }

  if ( gameGo ) {

    collisionDetect();

    background(255);
    image(space, 0, 0); 

    if (countControl != second() ) {
      countControl = second();
      count++;
      time = count;
      if (time % 10 == 0) {
        updateSpeed();
      }
    }


    for (int i = 0; i < num_enemys; i++) {
      enemies[i].update();
      enemies[i].draw();
    }

    fill(255);
    if (time == 60) {
      minutes += 1;
      time = 0;
      count = 0;
    }
    if (time < 10) {
      text(minutes + ":0" + time, 20, 50);
    }
    else {
      text(minutes + ":" + time, 20, 50);
    }
    score = minutes + ":" + time;
  }

  if ( gameOver ) {
    gameGo = false;
    gameOver = true;

    mainMenu = false;
    background(0xff142E5F);
    //noStroke();
    fill(0xff02A8BC);
    rect(10, 10, 220, 50);
    rect(10, 80, 220, 50);
    fill(0);
    text("Game Over!", 38, 50);
    if (time < 10) {
      fill(0);
      text(minutes + ":0" + time, 95, 120);
    }
    else {
      fill(0);
      text(minutes + ":" + time, 95, 120);
    }
    replay.draw();
    main.draw();
  }

  if ( replay.clicked ) {
    gameOver = false;
    gameGo = true;
    mainMenu = false;
    count = 0;
    minutes = 0;
    speed = startingSpeed;
    clr = color(255, 0, 0);
    replay = new  Button(252, 10, 180, 50, "Replay", 292, 48);
  }

  if ( main.clicked ) {
    gameOver = false;
    gameGo = false;
    mainMenu = true;
    count = 0;
    minutes = 0;
  }

  //Cursor is an image


  // set player position
  player.pos.x = mouseX;
  player.pos.y = mouseY;
  player.draw();

  pushMatrix();
  translate(mouseX-10, mouseY-10);
  image(b, 0, 0, 30, 20);

  popMatrix();
}

public void mouseClicked() {

  //println("MouseX: " + mouseX + " -- " + "MouseY: " + mouseY);


  if ( mainMenu ) {
    start.mouseClicked();
  }


  if ( gameOver ) {
    replay.mouseClicked();
    main.mouseClicked();
  }
}




class Particle {

  PVector pos, vel;

  Particle() {
    pos = new PVector(); // position vector
    vel = new PVector(); // velocity vector
  }
}
class Player extends Sprite
{

  float[] trailx = new float[25];
  float[] traily = new float[25]; 

  Player() {
    super();


    radius = 5;   

    for (int i = 0; i < trailx.length; i ++ ) {
      trailx[i] = 0;
      traily[i] = 0;
    }
  } 

  public void draw() {


    if (_DEBUG_) {
      drawBounds(pos, radius);
    }   

    // Shift array values for trail
    for (int i = 0; i < trailx.length-1; i ++ ) {
      trailx[i] = trailx[i+1];
      traily[i] = traily[i+1];
    }       



    noStroke();
    fill(0, 0, 0);
    ellipse(pos.x, pos.y, 5, 5);


    // set trail head to new the new location
    trailx[trailx.length-1] = pos.x;
    traily[traily.length-1] = pos.y;     

    // Draw trails
    /*
    noFill();
     strokeWeight(2);
     
     int trailLength = trailx.length;
     for (int i = 1; i < trailLength; i ++ ) {
     // Draw an ellipse for each element in the arrays.
     // Color and size are tied to the loop's counter: i.
     
     stroke(random(0, 255), random(0, 255), random(0, 255), 255 / (trailLength / i));
     strokeWeight(20);
     strokeCap(ROUND);
     line(trailx[i], traily[i], trailx[i-1], traily[i-1]);
     }       
     endShape();
     */
  }
}

class Sprite extends Particle
{
  float radius;

  Sprite() {
    super();
    radius = 25;
  }

  public boolean hitTest( Sprite test ) {
    if (_CIRCLE_HITTEST_) {
      return circleCollision(this.pos, this.radius, test.pos, test.radius);
    }
    else {
      return rectCollision(this.pos, this.radius, test.pos, test.radius);
    }
  }
}

class Button {
 
  int x;
  int y;
  int _x;
  int _y;
  String txt;
  int x2;
  int y2;
 
  boolean clicked = false;
 
  Button(int xPos, int yPos, int xSize, int ySize, String ln, int xPos2, int yPos2) {
    x   = xPos;
    y   = yPos;
    _x  = xSize;
    _y  = ySize;
    txt = ln;
    x2  = xPos2;
    y2  = yPos2;
  }
 
  public void draw() {
    if (mouseX > x && mouseX < x + _x &&
      mouseY > y && mouseY < y + _y) {
      //noStroke();
      fill(255, 0, 0);
    }
    else {
      //noStroke();
      fill(0, 255, 0);
    }
    rect(x, y, _x, _y);
    fill(0);
    text(txt, x2, y2);
  }
 
  public void mouseClicked() {
    if (mouseX > x && mouseX < x + _x &&
      mouseY > y && mouseY < y + _y) {
      clicked = true;
    }
  }
}
class Enemy extends Sprite {
 
  float speedVar;
 
  Enemy() {
    super();
 
    radius = 5;
 
    pos = new PVector(random(0, width), random(0, height));
    speedVar = random(0.5f, 1.5f);
  }
 
  public void update() {
 
    float rainHeight = 10 * speed/3;
 
    // set position
    if ( pos.x > 0 )
      pos.add(new PVector(-speed * speedVar, 0));
    else
      pos.set(width, random(0, height), 0);
  }
 
 
 
  public void draw() {
 
    // draw debug
    if (_DEBUG_) {
      drawBounds(pos, radius);
    }
 
    // draw enemy
    fill(clr);
    noStroke();

    ellipse(pos.x, pos.y, 18, 19);
    image(meteor, pos.x-16, pos.y-17, 35, 35);
  }
}
 
 
 
public boolean circleCollision(PVector pos1, float radius1, PVector pos2, float radius2) {
  final double a  = radius1 + radius2;
  final double dx = pos1.x - pos2.x;
  final double dy = pos1.y - pos2.y;
  return a * a > (dx * dx + dy * dy);
}
 
 
public boolean rectCollision(PVector pos1, float radius1, PVector pos2, float radius2) {
  return pos1.x - radius1 <= pos2.x + radius2 && pos1.x + radius1 >= pos2.x - radius2 &&
    pos1.y - radius1 <= pos2.y + radius2 && pos1.y + radius1 >= pos2.y - radius2;
}
 
 
public void drawBounds(PVector pos, float radius) {
  noFill();
  strokeWeight(1);
  stroke(255, 255, 0);
  if (_CIRCLE_HITTEST_) {
    ellipse(pos.x, pos.y, radius*2, radius*2);
  }
  else {
    float rect_size = radius*2;
    rect(pos.x - rect_size/2, pos.y - rect_size/2, rect_size, rect_size);
  }
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--present", "--bgcolor=#666666", "--stop-color=#cccccc", "nyancat" });
  }
}
